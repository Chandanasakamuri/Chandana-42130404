public class LabCourse extends Course {
    private String labRoom;
    private String labInstructor;

    public LabCourse(String courseId, String courseName, String instructor, 
                    int credits, int capacity, String labRoom, String labInstructor) {
        super(courseId, courseName, instructor, credits, capacity);
        this.labRoom = labRoom;
        this.labInstructor = labInstructor;
    }

    @Override
    public String getCourseType() {
        return "Lab Course";
    }

    public String getLabRoom() {
        return labRoom;
    }

    public String getLabInstructor() {
        return labInstructor;
    }
}