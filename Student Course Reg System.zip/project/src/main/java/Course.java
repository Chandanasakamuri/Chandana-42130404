public abstract class Course {
    private String courseId;
    private String courseName;
    private String instructor;
    private int credits;
    private int capacity;
    private List<Student> enrolledStudents;
    private List<Student> waitingList;
    private Set<Course> prerequisites;

    public Course(String courseId, String courseName, String instructor, int credits, int capacity) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.instructor = instructor;
        this.credits = credits;
        this.capacity = capacity;
        this.enrolledStudents = new ArrayList<>();
        this.waitingList = new ArrayList<>();
        this.prerequisites = new HashSet<>();
    }

    public String getCourseId() {
        return courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public String getInstructor() {
        return instructor;
    }

    public int getCredits() {
        return credits;
    }

    public boolean hasAvailableSeats() {
        return enrolledStudents.size() < capacity;
    }

    public void addStudent(Student student) {
        if (hasAvailableSeats()) {
            enrolledStudents.add(student);
        } else {
            waitingList.add(student);
        }
    }

    public void removeStudent(Student student) {
        enrolledStudents.remove(student);
        if (!waitingList.isEmpty()) {
            Student nextStudent = waitingList.remove(0);
            enrolledStudents.add(nextStudent);
        }
    }

    public void addPrerequisite(Course course) {
        prerequisites.add(course);
    }

    public boolean hasPrerequisites(Student student) {
        return prerequisites.stream()
                .allMatch(prereq -> student.getEnrolledCourses().contains(prereq));
    }

    public abstract String getCourseType();

    @Override
    public String toString() {
        return "Course{" +
                "id='" + courseId + '\'' +
                ", name='" + courseName + '\'' +
                ", instructor='" + instructor + '\'' +
                ", credits=" + credits +
                ", enrolled=" + enrolledStudents.size() +
                "/" + capacity +
                '}';
    }
}