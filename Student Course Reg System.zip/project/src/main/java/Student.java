public class Student {
    private String studentId;
    private String name;
    private String email;
    private List<Course> enrolledCourses;
    private static final int MAX_COURSES = 5;

    public Student(String studentId, String name, String email) {
        this.studentId = studentId;
        this.name = name;
        this.email = email;
        this.enrolledCourses = new ArrayList<>();
    }

    public String getStudentId() {
        return studentId;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public List<Course> getEnrolledCourses() {
        return new ArrayList<>(enrolledCourses);
    }

    public boolean canEnrollInMoreCourses() {
        return enrolledCourses.size() < MAX_COURSES;
    }

    public boolean enrollInCourse(Course course) {
        if (!canEnrollInMoreCourses()) {
            System.out.println("Maximum course limit reached!");
            return false;
        }
        if (enrolledCourses.contains(course)) {
            System.out.println("Already enrolled in this course!");
            return false;
        }
        if (course.hasAvailableSeats()) {
            enrolledCourses.add(course);
            course.addStudent(this);
            return true;
        }
        return false;
    }

    public boolean withdrawFromCourse(Course course) {
        if (enrolledCourses.remove(course)) {
            course.removeStudent(this);
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id='" + studentId + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}