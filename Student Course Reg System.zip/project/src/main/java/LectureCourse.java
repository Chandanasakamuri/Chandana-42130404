public class LectureCourse extends Course {
    private String classroom;

    public LectureCourse(String courseId, String courseName, String instructor, 
                        int credits, int capacity, String classroom) {
        super(courseId, courseName, instructor, credits, capacity);
        this.classroom = classroom;
    }

    @Override
    public String getCourseType() {
        return "Lecture Course";
    }

    public String getClassroom() {
        return classroom;
    }
}