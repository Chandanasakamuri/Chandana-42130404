public class RegistrationSystem {
    private Map<String, Student> students;
    private Map<String, Course> courses;

    public RegistrationSystem() {
        this.students = new HashMap<>();
        this.courses = new HashMap<>();
    }

    public void registerStudent(String studentId, String name, String email) {
        if (!students.containsKey(studentId)) {
            students.put(studentId, new Student(studentId, name, email));
            System.out.println("Student registered successfully!");
        } else {
            System.out.println("Student ID already exists!");
        }
    }

    public void addCourse(Course course) {
        if (!courses.containsKey(course.getCourseId())) {
            courses.put(course.getCourseId(), course);
            System.out.println("Course added successfully!");
        } else {
            System.out.println("Course ID already exists!");
        }
    }

    public void enrollStudentInCourse(String studentId, String courseId) {
        Student student = students.get(studentId);
        Course course = courses.get(courseId);

        if (student == null || course == null) {
            System.out.println("Student or course not found!");
            return;
        }

        if (!course.hasPrerequisites(student)) {
            System.out.println("Prerequisites not met!");
            return;
        }

        if (student.enrollInCourse(course)) {
            System.out.println("Enrollment successful!");
        } else {
            System.out.println("Enrollment failed!");
        }
    }

    public void withdrawStudentFromCourse(String studentId, String courseId) {
        Student student = students.get(studentId);
        Course course = courses.get(courseId);

        if (student == null || course == null) {
            System.out.println("Student or course not found!");
            return;
        }

        if (student.withdrawFromCourse(course)) {
            System.out.println("Withdrawal successful!");
        } else {
            System.out.println("Withdrawal failed!");
        }
    }

    public void viewEnrolledCourses(String studentId) {
        Student student = students.get(studentId);
        if (student == null) {
            System.out.println("Student not found!");
            return;
        }

        List<Course> enrolledCourses = student.getEnrolledCourses();
        if (enrolledCourses.isEmpty()) {
            System.out.println("No courses enrolled!");
        } else {
            System.out.println("Enrolled courses for " + student.getName() + ":");
            enrolledCourses.forEach(System.out::println);
        }
    }

    public void viewCourseDetails(String courseId) {
        Course course = courses.get(courseId);
        if (course == null) {
            System.out.println("Course not found!");
            return;
        }
        System.out.println(course);
    }
}