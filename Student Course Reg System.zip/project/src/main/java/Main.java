import java.util.Scanner;

public class Main {
    private static RegistrationSystem system = new RegistrationSystem();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            displayMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    registerNewStudent();
                    break;
                case 2:
                    addNewCourse();
                    break;
                case 3:
                    enrollInCourse();
                    break;
                case 4:
                    withdrawFromCourse();
                    break;
                case 5:
                    viewEnrolledCourses();
                    break;
                case 6:
                    viewCourseDetails();
                    break;
                case 7:
                    System.out.println("Thank you for using the Student Course Registration System!");
                    return;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private static void displayMenu() {
        System.out.println("\nStudent Course Registration System");
        System.out.println("1. Register New Student");
        System.out.println("2. Add New Course");
        System.out.println("3. Enroll in a Course");
        System.out.println("4. Withdraw from a Course");
        System.out.println("5. View Enrolled Courses");
        System.out.println("6. View Course Details");
        System.out.println("7. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void registerNewStudent() {
        System.out.print("Enter Student ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter Student Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Student Email: ");
        String email = scanner.nextLine();

        system.registerStudent(id, name, email);
    }

    private static void addNewCourse() {
        System.out.print("Enter Course Type (1 for Lecture, 2 for Lab): ");
        int type = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter Course ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter Course Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Instructor Name: ");
        String instructor = scanner.nextLine();
        System.out.print("Enter Credits: ");
        int credits = scanner.nextInt();
        System.out.print("Enter Capacity: ");
        int capacity = scanner.nextInt();
        scanner.nextLine();

        Course course;
        if (type == 1) {
            System.out.print("Enter Classroom: ");
            String classroom = scanner.nextLine();
            course = new LectureCourse(id, name, instructor, credits, capacity, classroom);
        } else {
            System.out.print("Enter Lab Room: ");
            String labRoom = scanner.nextLine();
            System.out.print("Enter Lab Instructor: ");
            String labInstructor = scanner.nextLine();
            course = new LabCourse(id, name, instructor, credits, capacity, labRoom, labInstructor);
        }

        system.addCourse(course);
    }

    private static void enrollInCourse() {
        System.out.print("Enter Student ID: ");
        String studentId = scanner.nextLine();
        System.out.print("Enter Course ID: ");
        String courseId = scanner.nextLine();

        system.enrollStudentInCourse(studentId, courseId);
    }

    private static void withdrawFromCourse() {
        System.out.print("Enter Student ID: ");
        String studentId = scanner.nextLine();
        System.out.print("Enter Course ID: ");
        String courseId = scanner.nextLine();

        system.withdrawStudentFromCourse(studentId, courseId);
    }

    private static void viewEnrolledCourses() {
        System.out.print("Enter Student ID: ");
        String studentId = scanner.nextLine();

        system.viewEnrolledCourses(studentId);
    }

    private static void viewCourseDetails() {
        System.out.print("Enter Course ID: ");
        String courseId = scanner.nextLine();

        system.viewCourseDetails(courseId);
    }
}