export type RoomType = 'Single' | 'Double' | 'Suite';

export interface Room {
  id: string;
  roomNumber: string;
  roomType: RoomType;
  isAvailable: boolean;
  pricePerNight: number;
  description: string;
  imageUrl: string;
}

export interface Guest {
  id: string;
  name: string;
  email: string;
  phone: string;
}

export interface Booking {
  id: string;
  guestId: string;
  roomId: string;
  checkInDate: string;
  checkOutDate: string;
  totalCost: number;
  specialRequests?: string;
  status: 'confirmed' | 'cancelled' | 'completed';
  paymentStatus: 'pending' | 'paid';
}