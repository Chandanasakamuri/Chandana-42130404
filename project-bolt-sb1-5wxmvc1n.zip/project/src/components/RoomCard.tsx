import React from 'react';
import { Room } from '../types';
import { Calendar, Users, DollarSign } from 'lucide-react';

interface RoomCardProps {
  room: Room;
  onBookNow: (roomId: string) => void;
}

export function RoomCard({ room, onBookNow }: RoomCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <img 
        src={room.imageUrl} 
        alt={room.description}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <div className="flex justify-between items-center mb-2">
          <h3 className="text-lg font-semibold">{`Room ${room.roomNumber}`}</h3>
          <span className={`px-2 py-1 rounded-full text-sm ${
            room.isAvailable ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
          }`}>
            {room.isAvailable ? 'Available' : 'Booked'}
          </span>
        </div>
        <p className="text-gray-600 mb-4">{room.description}</p>
        <div className="flex items-center gap-4 mb-4">
          <div className="flex items-center gap-1">
            <Users size={16} className="text-gray-500" />
            <span className="text-sm text-gray-600">{room.roomType}</span>
          </div>
          <div className="flex items-center gap-1">
            <DollarSign size={16} className="text-gray-500" />
            <span className="text-sm text-gray-600">${room.pricePerNight}/night</span>
          </div>
        </div>
        <button
          onClick={() => onBookNow(room.id)}
          disabled={!room.isAvailable}
          className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 
                   disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
        >
          {room.isAvailable ? 'Book Now' : 'Not Available'}
        </button>
      </div>
    </div>
  );
}