import React, { useState } from 'react';
import { Room, Guest, Booking } from '../types';

interface BookingFormProps {
  room: Room;
  onSubmit: (booking: Omit<Booking, 'id' | 'status' | 'paymentStatus'>) => void;
  onCancel: () => void;
}

export function BookingForm({ room, onSubmit, onCancel }: BookingFormProps) {
  const [guest, setGuest] = useState<Omit<Guest, 'id'>>({
    name: '',
    email: '',
    phone: '',
  });
  const [dates, setDates] = useState({
    checkIn: '',
    checkOut: '',
  });
  const [specialRequests, setSpecialRequests] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nights = Math.ceil(
      (new Date(dates.checkOut).getTime() - new Date(dates.checkIn).getTime()) / 
      (1000 * 60 * 60 * 24)
    );
    
    onSubmit({
      guestId: '', // Will be generated
      roomId: room.id,
      checkInDate: dates.checkIn,
      checkOutDate: dates.checkOut,
      totalCost: room.pricePerNight * nights,
      specialRequests,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700">Name</label>
        <input
          type="text"
          required
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={guest.name}
          onChange={(e) => setGuest({ ...guest, name: e.target.value })}
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700">Email</label>
        <input
          type="email"
          required
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={guest.email}
          onChange={(e) => setGuest({ ...guest, email: e.target.value })}
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700">Phone</label>
        <input
          type="tel"
          required
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          value={guest.phone}
          onChange={(e) => setGuest({ ...guest, phone: e.target.value })}
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Check-in Date</label>
          <input
            type="date"
            required
            min={new Date().toISOString().split('T')[0]}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={dates.checkIn}
            onChange={(e) => setDates({ ...dates, checkIn: e.target.value })}
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700">Check-out Date</label>
          <input
            type="date"
            required
            min={dates.checkIn || new Date().toISOString().split('T')[0]}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            value={dates.checkOut}
            onChange={(e) => setDates({ ...dates, checkOut: e.target.value })}
          />
        </div>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700">Special Requests</label>
        <textarea
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          rows={3}
          value={specialRequests}
          onChange={(e) => setSpecialRequests(e.target.value)}
        />
      </div>
      
      <div className="flex justify-end space-x-2">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
        >
          Book Now
        </button>
      </div>
    </form>
  );
}