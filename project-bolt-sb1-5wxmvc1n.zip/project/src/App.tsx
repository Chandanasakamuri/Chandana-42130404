import React, { useState } from 'react';
import { Hotel, BedDouble } from 'lucide-react';
import { RoomCard } from './components/RoomCard';
import { BookingForm } from './components/BookingForm';
import { rooms } from './data/rooms';
import { Room, Booking } from './types';

function App() {
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null);
  const [bookings, setBookings] = useState<Booking[]>([]);

  const handleBookNow = (roomId: string) => {
    const room = rooms.find(r => r.id === roomId);
    if (room) {
      setSelectedRoom(room);
    }
  };

  const handleBookingSubmit = (bookingData: Omit<Booking, 'id' | 'status' | 'paymentStatus'>) => {
    const newBooking: Booking = {
      ...bookingData,
      id: Math.random().toString(36).substr(2, 9),
      status: 'confirmed',
      paymentStatus: 'pending',
    };
    setBookings([...bookings, newBooking]);
    setSelectedRoom(null);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-2">
            <Hotel className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">Luxury Hotel</h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {selectedRoom ? (
          <div className="max-w-2xl mx-auto">
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold">Book Room {selectedRoom.roomNumber}</h2>
                <BedDouble className="h-6 w-6 text-blue-600" />
              </div>
              <BookingForm
                room={selectedRoom}
                onSubmit={handleBookingSubmit}
                onCancel={() => setSelectedRoom(null)}
              />
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {rooms.map((room) => (
              <RoomCard
                key={room.id}
                room={room}
                onBookNow={handleBookNow}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

export default App;