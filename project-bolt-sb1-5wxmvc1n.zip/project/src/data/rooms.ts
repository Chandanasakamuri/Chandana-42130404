import { Room } from '../types';

export const rooms: Room[] = [
  {
    id: '1',
    roomNumber: '101',
    roomType: 'Single',
    isAvailable: true,
    pricePerNight: 100,
    description: 'Cozy single room with city view',
    imageUrl: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304',
  },
  {
    id: '2',
    roomNumber: '102',
    roomType: 'Double',
    isAvailable: true,
    pricePerNight: 150,
    description: 'Spacious double room with garden view',
    imageUrl: 'https://images.unsplash.com/photo-1618773928121-c32242e63f39',
  },
  {
    id: '3',
    roomNumber: '103',
    roomType: 'Suite',
    isAvailable: true,
    pricePerNight: 250,
    description: 'Luxury suite with panoramic ocean view',
    imageUrl: 'https://images.unsplash.com/photo-1590490360182-c33d57733427',
  },
];